<header>
    <nav class="navbar navbar-expand-lg navbar-light bg-white border-bottom shadow-sm py-3">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
                <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Ambung e-MAC" height="40">
            </a>

            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <!-- Search Bar -->
                <form class="d-flex mx-auto" style="width: 50%;" action="<?php echo e(route('products.index')); ?>" method="GET">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Search products..." name="search"
                            value="<?php echo e(request('search')); ?>">
                        <button class="btn btn-primary" type="submit">
                            <i class="fas fa-search"></i>
                        </button>
                    </div>
                </form>

                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <!-- Categories Dropdown -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="categoriesDropdown" role="button"
                            data-bs-toggle="dropdown">
                            <i class="fas fa-list me-1"></i> Categories
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="categoriesDropdown">
                            <?php $__currentLoopData = \App\Models\Category::take(10)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a class="dropdown-item"
                                    href="<?php echo e(route('products.index', ['category' => $category->id])); ?>"><?php echo e($category->name); ?></a>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item" href="<?php echo e(route('categories.index')); ?>">All Categories</a></li>
                        </ul>
                    </li>

                    <!-- Cart -->
                    <li class="nav-item">
                        <a class="nav-link position-relative" href="<?php echo e(route('cart.index')); ?>">
                            <i class="fas fa-shopping-cart"></i>

                            <?php
                            $cartCount = auth()->check()
                            ? \App\Models\Cart::where('user_id', auth()->id())->sum('quantity')
                            : 0;
                            ?>

                            
                            <span
                                class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger cart-count"
                                style="<?php echo e($cartCount > 0 ? '' : 'display:none'); ?>">
                                <?php echo e($cartCount); ?>

                            </span>
                        </a>
                    </li>

                    <!-- Authentication Links -->
                    <?php if(auth()->guard()->guest()): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('login')); ?>">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('register')); ?>">Register</a>
                    </li>
                    <?php else: ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                            data-bs-toggle="dropdown">
                            <img src="<?php echo e(auth()->user()->profile_photo_url ?? 'https://ui-avatars.com/api/?name='.urlencode(auth()->user()->name)); ?>"
                                class="rounded-circle me-1" width="24" height="24" alt="<?php echo e(auth()->user()->name); ?>">
                            <?php echo e(auth()->user()->name); ?>

                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <?php if(auth()->user()->role === 'admin'): ?>
                            <li><a class="dropdown-item" href="<?php echo e(route('admin.dashboard')); ?>">Admin Dashboard</a></li>
                            <?php elseif(auth()->user()->role === 'seller'): ?>
                            <li><a class="dropdown-item" href="<?php echo e(route('seller.dashboard')); ?>">Seller Dashboard</a>
                            </li>
                            <?php endif; ?>
                            <li><a class="dropdown-item" href="<?php echo e(route('profile.show')); ?>">My Profile</a></li>
                            <li><a class="dropdown-item" href="<?php echo e(route('orders.index')); ?>">My Orders</a></li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li>
                                <form method="POST" action="<?php echo e(route('logout')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="dropdown-item">Logout</button>
                                </form>
                            </li>
                        </ul>
                    </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Category Menu -->
    <div class="bg-light border-bottom">
        <div class="container">
            <div class="d-flex overflow-auto py-2">
                <?php $__currentLoopData = \App\Models\Category::take(12)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('products.index', ['category' => $category->id])); ?>"
                    class="text-decoration-none text-dark me-4 py-2">
                    <?php echo e($category->name); ?>

                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</header><?php /**PATH D:\ambung-emacs\resources\views/components/header.blade.php ENDPATH**/ ?>