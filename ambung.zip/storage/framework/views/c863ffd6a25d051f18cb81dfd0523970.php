<?php if(session('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <div class="d-flex">
        <div class="me-3">
            <i class="fas fa-check-circle fa-2x"></i>
        </div>
        <div>
            <h5 class="alert-heading">Success!</h5>
            <p class="mb-0"><?php echo e(session('success')); ?></p>
        </div>
    </div>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>

<?php if(session('error')): ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <div class="d-flex">
        <div class="me-3">
            <i class="fas fa-exclamation-circle fa-2x"></i>
        </div>
        <div>
            <h5 class="alert-heading">Error!</h5>
            <p class="mb-0"><?php echo e(session('error')); ?></p>
        </div>
    </div>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>

<?php if(session('warning')): ?>
<div class="alert alert-warning alert-dismissible fade show" role="alert">
    <div class="d-flex">
        <div class="me-3">
            <i class="fas fa-exclamation-triangle fa-2x"></i>
        </div>
        <div>
            <h5 class="alert-heading">Warning!</h5>
            <p class="mb-0"><?php echo e(session('warning')); ?></p>
        </div>
    </div>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>

<?php if(session('info')): ?>
<div class="alert alert-info alert-dismissible fade show" role="alert">
    <div class="d-flex">
        <div class="me-3">
            <i class="fas fa-info-circle fa-2x"></i>
        </div>
        <div>
            <h5 class="alert-heading">Information</h5>
            <p class="mb-0"><?php echo e(session('info')); ?></p>
        </div>
    </div>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>

<?php if($errors->any()): ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <div class="d-flex">
        <div class="me-3">
            <i class="fas fa-exclamation-circle fa-2x"></i>
        </div>
        <div>
            <h5 class="alert-heading">Please fix the following errors:</h5>
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?><?php /**PATH D:\ambung-emacs\resources\views/components/alert.blade.php ENDPATH**/ ?>