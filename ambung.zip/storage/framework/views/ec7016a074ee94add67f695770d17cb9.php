<?php $__env->startSection('title', 'Products'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row g-4">
        <!-- Filters Sidebar -->
        <div class="col-lg-3">
            <div class="card border-0 shadow-sm mb-4 sticky-top" style="top: 20px; z-index: 1;">
                <div class="card-header bg-white">
                    <h5 class="mb-0">Filters</h5>
                </div>
                <div class="card-body" x-data="filterComponent()">
                    <form id="filterForm" action="<?php echo e(route('products.index')); ?>" method="GET">
                        <!-- Preserve other parameters -->
                        <?php if(request('search')): ?>
                        <input type="hidden" name="search" value="<?php echo e(request('search')); ?>">
                        <?php endif; ?>

                        <!-- Category Filter -->
                        <div class="mb-4">
                            <h6 class="mb-3">Categories</h6>
                            <div class="overflow-auto" style="max-height: 200px;">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-check mb-2">
                                    <input class="form-check-input" type="checkbox" name="categories[]"
                                        id="category<?php echo e($category->id); ?>" value="<?php echo e($category->id); ?>"
                                        <?php echo e(in_array($category->id, $selectedCategories ?? []) ? 'checked' : ''); ?>

                                        @change="submitForm">
                                    <label class="form-check-label" for="category<?php echo e($category->id); ?>">
                                        <?php echo e($category->name); ?> (<?php echo e($category->products_count ?? 0); ?>)
                                    </label>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>

                        <!-- Price Range Filter -->
                        <div class="mb-4">
                            <h6 class="mb-3">Price Range</h6>
                            <div class="row g-2">
                                <div class="col-6">
                                    <input type="number" class="form-control form-control-sm" name="min_price"
                                        placeholder="Min" value="<?php echo e(request('min_price')); ?>" @change="submitForm">
                                </div>
                                <div class="col-6">
                                    <input type="number" class="form-control form-control-sm" name="max_price"
                                        placeholder="Max" value="<?php echo e(request('max_price')); ?>" @change="submitForm">
                                </div>
                            </div>
                            <?php if(isset($priceRange)): ?>
                            <small class="text-muted d-block mt-2">
                                Rp <?php echo e(number_format($priceRange['min'], 0, ',', '.')); ?> -
                                Rp <?php echo e(number_format($priceRange['max'], 0, ',', '.')); ?>

                            </small>
                            <?php endif; ?>
                        </div>

                        <!-- Sort Filter -->
                        <div class="mb-4">
                            <h6 class="mb-3">Sort By</h6>
                            <select class="form-select form-select-sm" name="sort" @change="submitForm">
                                <option value="newest" <?php echo e(request('sort') == 'newest' ? 'selected' : ''); ?>>Newest
                                </option>
                                <option value="price_low" <?php echo e(request('sort') == 'price_low' ? 'selected' : ''); ?>>Price:
                                    Low to High</option>
                                <option value="price_high" <?php echo e(request('sort') == 'price_high' ? 'selected' : ''); ?>>
                                    Price: High to Low</option>
                                <option value="popularity" <?php echo e(request('sort') == 'popularity' ? 'selected' : ''); ?>>Most
                                    Popular</option>
                            </select>
                        </div>

                        <!-- Clear Filters -->
                        <?php if(request()->anyFilled(['categories', 'category', 'min_price', 'max_price', 'sort',
                        'search'])): ?>
                        <a href="<?php echo e(route('products.index')); ?>" class="btn btn-sm btn-outline-secondary w-100">
                            <i class="fas fa-times me-1"></i> Clear Filters
                        </a>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>

        <!-- Products Grid -->
        <div class="col-lg-9">
            <!-- Results Header -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h4 class="mb-0">
                    <?php if(request('search')): ?>
                    Search Results for "<?php echo e(request('search')); ?>"
                    <?php else: ?>
                    All Products
                    <?php endif; ?>
                </h4>
                <div class="text-muted">
                    <?php echo e($products->total()); ?> products found
                </div>
            </div>

            <!-- Selected Filters -->
            <?php if($selectedCategories && count($selectedCategories) > 0): ?>
            <div class="mb-3">
                <span class="text-muted me-2">Active filters:</span>
                <?php $__currentLoopData = $categories->whereIn('id', $selectedCategories); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="badge bg-primary me-1">
                    <?php echo e($cat->name); ?>

                    <a href="<?php echo e(route('products.index', array_merge(request()->except('categories'), ['categories' => array_diff($selectedCategories, [$cat->id])]))); ?>"
                        class="text-white ms-1">×</a>
                </span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>

            <!-- Products Grid -->
            <div class="row g-4">
                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-md-4 col-sm-6">
                    <div class="card h-100 border-0 shadow-sm product-card">
                        <a href="<?php echo e(route('products.show', $product->slug)); ?>" class="text-decoration-none">
                            <?php if($product->images->isNotEmpty()): ?>
                            <img src="<?php echo e(Storage::url($product->images->first()->image_url)); ?>" class="card-img-top"
                                alt="<?php echo e($product->name); ?>">
                            <?php else: ?>
                            <img src="<?php echo e(asset('images/no-image.png')); ?>" class="card-img-top"
                                alt="<?php echo e($product->name); ?>">
                            <?php endif; ?>
                        </a>
                        <div class="card-body d-flex flex-column">
                            <h6 class="card-title">
                                <a href="<?php echo e(route('products.show', $product->slug)); ?>"
                                    class="text-decoration-none text-dark">
                                    <?php echo e($product->name); ?>

                                </a>
                            </h6>
                            <p class="text-muted small mb-2">
                                <?php echo e($product->category->name ?? 'Uncategorized'); ?>

                            </p>
                            <div class="mt-auto">
                                <div class="d-flex justify-content-between align-items-center">
                                    <span class="h5 mb-0 text-primary">
                                        Rp <?php echo e(number_format($product->price, 0, ',', '.')); ?>

                                    </span>
                                    <?php if($product->stock > 0): ?>
                                    <span class="badge bg-success">In Stock</span>
                                    <?php else: ?>
                                    <span class="badge bg-danger">Out of Stock</span>
                                    <?php endif; ?>
                                </div>
                                <?php if(auth()->guard()->check()): ?>
                                <?php if(auth()->user()->role === 'buyer'): ?>
                                <button class="btn btn-primary btn-sm w-100 mt-3"
                                    onclick="addToCart(<?php echo e($product->id); ?>)"
                                    <?php echo e($product->stock <= 0 ? 'disabled' : ''); ?>>
                                    <i class="fas fa-shopping-cart me-1"></i> Add to Cart
                                </button>
                                <?php endif; ?>
                                <?php else: ?>
                                <a href="<?php echo e(route('login')); ?>" class="btn btn-outline-primary btn-sm w-100 mt-3">
                                    <i class="fas fa-sign-in-alt me-1"></i> Login to Buy
                                </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-12">
                    <div class="text-center py-5">
                        <i class="fas fa-search fa-3x text-muted mb-3"></i>
                        <h5>No products found</h5>
                        <p class="text-muted">Try adjusting your filters or search terms</p>
                        <a href="<?php echo e(route('products.index')); ?>" class="btn btn-primary">
                            View All Products
                        </a>
                    </div>
                </div>
                <?php endif; ?>
            </div>

            <!-- Pagination -->
            <div class="mt-5">
                <?php echo e($products->appends(request()->query())->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    function filterComponent() {
    return {
        submitForm() {
            document.getElementById('filterForm').submit();
        }
    }
}

function addToCart(productId) {
    fetch('/cart/add', {
        method: 'POST',
        headers: {
            'Content-Type'   : 'application/json',
            'Accept'         : 'application/json',     // <– penting
            'X-Requested-With': 'XMLHttpRequest',      // <– penting
            'X-CSRF-TOKEN'   : document
                                .querySelector('meta[name="csrf-token"]')
                                .content
        },
        credentials: 'same-origin',                    // bawa session cookie
        body: JSON.stringify({
            product_id: productId,
            quantity  : 1
        })
    })
    .then(async (response) => {
        if (!response.ok) {          // 401 / 419 / 422, dll.
            // Coba ambil text agar mudah di-debug
            const text = await response.text();
            console.error('Non-200 response', response.status, text);
            throw new Error(`HTTP ${response.status}`);
        }

        const contentType = response.headers.get('content-type');
        if (!contentType || !contentType.includes('application/json')) {
            // Server malah balas HTML ⇒ kemungkinan redirect/login
            const text = await response.text();
            console.error('HTML received:', text.substring(0, 200));
            throw new Error('NON_JSON_RESPONSE');
        }

        return response.json();
    })
    .then(({ success, message, cart_count }) => {
        if (success) {
            updateCartCount(cart_count);
            alert(message ?? 'Produk masuk keranjang!');
        } else {
            alert(message ?? 'Gagal menambah produk');
        }
    })
    .catch((err) => {
        if (err.message === 'NON_JSON_RESPONSE') {
            // Arahkan user login atau tampilkan modal
            window.location.href = '<?php echo e(route('login')); ?>';
        } else {
            alert('Terjadi kesalahan, coba lagi');
        }
    });
}


function updateCartCount() {
    fetch('/cart/count')
        .then(response => response.json())
        .then(data => {
            const cartBadge = document.querySelector('.cart-count');
            if (cartBadge && data.count !== undefined) {
                cartBadge.textContent = data.count;
            }
        });
}
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<style>
    .product-card {
        transition: transform 0.2s, box-shadow 0.2s;
    }

    .product-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15) !important;
    }

    .product-card img {
        height: 200px;
        object-fit: cover;
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\ambung-emacs\resources\views/web/products/index.blade.php ENDPATH**/ ?>