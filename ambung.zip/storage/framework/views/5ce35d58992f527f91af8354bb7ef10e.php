<?php $__env->startSection('title', 'Orders'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <!-- Page Header -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h1 class="h3 mb-0">Orders</h1>
                    <p class="text-muted">Manage your customer orders</p>
                </div>
            </div>

            <!-- Order Stats -->
            <div class="row mb-4">
                <div class="col-md-3">
                    <div class="card text-center">
                        <div class="card-body">
                            <h3 class="text-info mb-1"><?php echo e($stats['new'] ?? 0); ?></h3>
                            <small class="text-muted">New Orders</small>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card text-center">
                        <div class="card-body">
                            <h3 class="text-warning mb-1"><?php echo e($stats['dispatched'] ?? 0); ?></h3>
                            <small class="text-muted">Processing</small>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card text-center">
                        <div class="card-body">
                            <h3 class="text-success mb-1"><?php echo e($stats['delivered'] ?? 0); ?></h3>
                            <small class="text-muted">Completed</small>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card text-center">
                        <div class="card-body">
                            <h3 class="text-danger mb-1"><?php echo e($stats['canceled'] ?? 0); ?></h3>
                            <small class="text-muted">Canceled</small>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Quick Filter Tabs -->
            <div class="card mb-4">
                <div class="card-body">
                    <ul class="nav nav-pills mb-3">
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('seller.orders.index') && !request('status') ? 'active' : ''); ?>"
                                href="<?php echo e(route('seller.orders.index')); ?>">
                                All Orders
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('seller.orders.new') ? 'active' : ''); ?>"
                                href="<?php echo e(route('seller.orders.new')); ?>">
                                New
                                <?php if(isset($stats['new']) && $stats['new'] > 0): ?>
                                <span class="badge bg-danger ms-1"><?php echo e($stats['new']); ?></span>
                                <?php endif; ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('seller.orders.processing') ? 'active' : ''); ?>"
                                href="<?php echo e(route('seller.orders.processing')); ?>">
                                Processing
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('seller.orders.completed') ? 'active' : ''); ?>"
                                href="<?php echo e(route('seller.orders.completed')); ?>">
                                Completed
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('seller.orders.canceled') ? 'active' : ''); ?>"
                                href="<?php echo e(route('seller.orders.canceled')); ?>">
                                Canceled
                            </a>
                        </li>
                    </ul>

                    <!-- Filters -->
                    <form method="GET" action="<?php echo e(route('seller.orders.index')); ?>">
                        <div class="row g-3">
                            <div class="col-md-3">
                                <input type="text" class="form-control" name="search" placeholder="Search orders..."
                                    value="<?php echo e(request('search')); ?>">
                            </div>
                            <div class="col-md-2">
                                <select class="form-select" name="status">
                                    <option value="">All Status</option>
                                    <option value="new" <?php echo e(request('status') === 'new' ? 'selected' : ''); ?>>
                                        new</option>
                                    <option value="confirmed" <?php echo e(request('status') === 'confirmed' ? 'selected' : ''); ?>>
                                        Confirmed</option>
                                    <option value="processing"
                                        <?php echo e(request('status') === 'processing' ? 'selected' : ''); ?>>Processing</option>
                                    <option value="shipped" <?php echo e(request('status') === 'shipped' ? 'selected' : ''); ?>>
                                        Shipped</option>
                                    <option value="delivered" <?php echo e(request('status') === 'delivered' ? 'selected' : ''); ?>>
                                        Delivered</option>
                                    <option value="completed" <?php echo e(request('status') === 'completed' ? 'selected' : ''); ?>>
                                        Completed</option>
                                    <option value="canceled" <?php echo e(request('status') === 'canceled' ? 'selected' : ''); ?>>
                                        Canceled</option>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <input type="date" class="form-control" name="date_from"
                                    value="<?php echo e(request('date_from')); ?>">
                            </div>
                            <div class="col-md-2">
                                <input type="date" class="form-control" name="date_to" value="<?php echo e(request('date_to')); ?>">
                            </div>
                            <div class="col-md-3">
                                <div class="d-flex gap-2">
                                    <button type="submit" class="btn btn-outline-primary">
                                        <i class="fas fa-search me-1"></i> Filter
                                    </button>
                                    <a href="<?php echo e(route('seller.orders.index')); ?>" class="btn btn-outline-secondary">
                                        <i class="fas fa-times me-1"></i> Clear
                                    </a>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Orders Table -->
            <div class="card">
                <div class="card-body">
                    <?php if(isset($orders) && $orders->count() > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Order</th>
                                    <th>Customer</th>
                                    <th>Products</th>
                                    <th>Total</th>
                                    <th>Status</th>
                                    <th>Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <div>
                                            <strong>#<?php echo e($order->order_number); ?></strong><br>
                                            <small class="text-muted"><?php echo e($order->payment_method ?? 'N/A'); ?></small>
                                        </div>
                                    </td>
                                    <td>
                                        <div>
                                            <strong><?php echo e($order->user->name ?? 'Guest'); ?></strong><br>
                                            <small
                                                class="text-muted"><?php echo e($order->user->email ?? $order->customer_email); ?></small>
                                        </div>
                                    </td>
                                    <td>
                                        <div>
                                            <?php if($order->items && $order->items->count() > 0): ?>
                                            <?php $__currentLoopData = $order->items->take(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <small class="d-block"><?php echo e($item->product->name ?? 'Product'); ?>

                                                (<?php echo e($item->quantity); ?>x)</small>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($order->items->count() > 2): ?>
                                            <small class="text-muted">+<?php echo e($order->items->count() - 2); ?> more</small>
                                            <?php endif; ?>
                                            <?php else: ?>
                                            <small class="text-muted">No items</small>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    <td>
                                        <strong><?php echo e($order->formatted_total); ?></strong>
                                    </td>
                                    <td>
                                        <?php
                                        $statusColors = [
                                        'new' => 'warning',
                                        'confirmed' => 'info',
                                        'processing' => 'primary',
                                        'shipped' => 'info',
                                        'delivered' => 'success',
                                        'completed' => 'success',
                                        'canceled' => 'danger'
                                        ];
                                        $color = $statusColors[$order->status] ?? 'secondary';
                                        ?>
                                        <span class="badge bg-<?php echo e($color); ?>"><?php echo e(ucfirst($order->status)); ?></span>
                                    </td>
                                    <td>
                                        <small><?php echo e($order->created_at->format('M d, Y')); ?></small><br>
                                        <small class="text-muted"><?php echo e($order->created_at->format('H:i')); ?></small>
                                    </td>
                                    <td>
                                        <div class="dropdown">
                                            <button class="btn btn-sm btn-outline-secondary dropdown-toggle"
                                                type="button" data-bs-toggle="dropdown">
                                                Actions
                                            </button>
                                            <ul class="dropdown-menu">
                                                <li>
                                                    <a class="dropdown-item"
                                                        href="<?php echo e(route('seller.orders.show', $order)); ?>">
                                                        <i class="fas fa-eye me-1"></i> View Details
                                                    </a>
                                                </li>
                                                <?php if($order->status === 'new'): ?>
                                                <li>
                                                    <form action="<?php echo e(route('seller.orders.status.update', $order)); ?>"
                                                        method="POST" class="d-inline">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('PATCH'); ?>
                                                        <input type="hidden" name="status" value="accepted">
                                                        <button type="submit" class="dropdown-item">
                                                            <i class="fas fa-check me-1"></i> Accept Order
                                                        </button>
                                                    </form>
                                                </li>
                                                <li>
                                                    <hr class="dropdown-divider">
                                                </li>
                                                <li>
                                                    <form action="<?php echo e(route('seller.orders.status.update', $order)); ?>"
                                                        method="POST" class="d-inline"
                                                        onsubmit="return confirm('Are you sure you want to cancel this order?')">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('PATCH'); ?>
                                                        <input type="hidden" name="status" value="canceled">
                                                        <button type="submit" class="dropdown-item text-danger">
                                                            <i class="fas fa-times me-1"></i> Cancel Order
                                                        </button>
                                                    </form>
                                                </li>
                                                <?php endif; ?>

                                                <?php if($order->status === 'accepted'): ?>
                                                <li>
                                                    <form action="<?php echo e(route('seller.orders.status.update', $order)); ?>"
                                                        method="POST" class="d-inline">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('PATCH'); ?>
                                                        <input type="hidden" name="status" value="dispatched">
                                                        <button type="submit" class="dropdown-item">
                                                            <i class="fas fa-shipping-fast me-1"></i> Dispatch Order
                                                        </button>
                                                    </form>
                                                </li>
                                                <li>
                                                    <hr class="dropdown-divider">
                                                </li>
                                                <li>
                                                    <form action="<?php echo e(route('seller.orders.status.update', $order)); ?>"
                                                        method="POST" class="d-inline"
                                                        onsubmit="return confirm('Are you sure you want to cancel this order?')">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('PATCH'); ?>
                                                        <input type="hidden" name="status" value="canceled">
                                                        <button type="submit" class="dropdown-item text-danger">
                                                            <i class="fas fa-times me-1"></i> Cancel Order
                                                        </button>
                                                    </form>
                                                </li>
                                                <?php endif; ?>

                                                <?php if($order->status === 'dispatched'): ?>
                                                <li>
                                                    <form action="<?php echo e(route('seller.orders.status.update', $order)); ?>"
                                                        method="POST" class="d-inline">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('PATCH'); ?>
                                                        <input type="hidden" name="status" value="delivered">
                                                        <button type="submit" class="dropdown-item">
                                                            <i class="fas fa-check-circle me-1"></i> Mark as Delivered
                                                        </button>
                                                    </form>
                                                </li>
                                                <?php endif; ?>

                                                <?php if(in_array($order->status, ['delivered', 'canceled'])): ?>
                                                <li>
                                                    <span class="dropdown-item-text text-muted">
                                                        <i class="fas fa-info-circle me-1"></i>
                                                        No actions available
                                                    </span>
                                                </li>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Pagination -->
                    <?php if(method_exists($orders, 'links')): ?>
                    <div class="d-flex justify-content-center mt-4">
                        <?php echo e($orders->links()); ?>

                    </div>
                    <?php endif; ?>
                    <?php else: ?>
                    <div class="text-center py-5">
                        <i class="fas fa-shopping-bag fa-3x text-muted mb-3"></i>
                        <h5 class="text-muted">No Orders Found</h5>
                        <p class="text-muted">You don't have any orders yet.</p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.seller', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\ambung-emacs\resources\views/seller/orders/index.blade.php ENDPATH**/ ?>